 <!-- Code for last view student classroom and getting their data  -->
        <?php
            $conn1 = mysqli_connect("localhost","root","","dbcognate");
            $sql1 = mysqli_query($conn1, "SELECT * FROM tblviewclass ORDER BY ID DESC LIMIT 1 ");
            $print_data = mysqli_fetch_row($sql1);
            $laststudentlogin1 = $print_data[5];
            $code = $print_data[1];
            $subject = $print_data[2];
            $section = $print_data[3];
            $teacheremail = $print_data[4];
        ?>
        
        <!-- Code for what lesson will be displayed in the textbox which is not displaying-->
        <?php

        $conn = mysqli_connect("localhost","root","","dbcognate");
        $sql = mysqli_query($conn, "SELECT * FROM tblstudenttakers WHERE Email='$laststudentlogin1' AND Code='$code ' AND Section='$section' AND TeacherEmail='$teacheremail'  ORDER BY LessonID DESC LIMIT 1 ");
        $printdata = mysqli_fetch_row($sql);
        $firstnumber = 0;
        $secondnumber = 1;
        $sumoftwonumbers = $firstnumber + $secondnumber;
        ?>

        <!-- end of navbar -->
        
                <!-- Code for student who currently logged in  -->
        <?php
            $conn1 = mysqli_connect("localhost","root","","dbcognate");
            $sql1 = mysqli_query($conn1, "SELECT * FROM tblviewclass ORDER BY ID DESC LIMIT 1 ");
            $print_data = mysqli_fetch_row($sql1);
            $laststudentlogin1 = $print_data[5];
            $code = $print_data[1];
            $subject = $print_data[2];
            $section = $print_data[3];
            $teacheremail = $print_data[4];
        ?>

    
        <!-- Code for the next lesson will be displayed in the table -->
        <?php 
            $host = "localhost";
            $dbUsername = "root";
            $dbPassword = "";
            $dbname = "dbcognate";
            
            $conn = new mysqli($host,$dbUsername,$dbPassword,$dbname) or die(mysqli_error($conn)); // Create connection
            
            if(isset($_GET['view'])){
                $ID = $_GET['view'];
                $sql = $conn->query("SELECT * FROM tbteacherlistoflessons WHERE Numb='$ID' AND Code='$code'") or die($conn->error);
                $row = $sql->fetch_array();                     
                $code = $row['Code'];
                $title = $row['Title'];
                $chapter = $row['Chapter'];
                $filelocation = $row['Filename'];
            }
        ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


<!-- Favicon icon-->
<link rel="shortcut icon" type="image/x-icon" href="https://codescandy.com/geeks/assets/images/favicon/favicon.ico">


<!-- Libs CSS -->
<link href="../assets/fonts/feather/feather.css" rel="stylesheet" />
<link href="../assets/libs/dragula/dist/dragula.min.css" rel="stylesheet" />
<link href="../assets/libs/%40mdi/font/css/materialdesignicons.min.css" rel="stylesheet" />
<link href="../assets/libs/prismjs/themes/prism.css" rel="stylesheet" />
<link href="../assets/libs/dropzone/dist/dropzone.css" rel="stylesheet" />
<link href="../assets/libs/magnific-popup/dist/magnific-popup.css" rel="stylesheet" />
<link href="../assets/libs/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
<link href="../assets/libs/%40yaireo/tagify/dist/tagify.css" rel="stylesheet">
<link href="../assets/libs/tiny-slider/dist/tiny-slider.css" rel="stylesheet">
<link href="../assets/libs/tippy.js/dist/tippy.css" rel="stylesheet">


<!-- Theme CSS -->
<link rel="stylesheet" href="../assets/css/theme.min.css">
  <title>Lesson | eSkwela</title>
</head>

 <body style="overflow:hidden">
      <?php
      $host = "localhost";
      $dbUsername = "root";
      $dbPassword = "";
      $dbname = "dbcognate";
      $mysqli = new mysqli($host,$dbUsername,$dbPassword,$dbname) or die(mysqli_error($mysqli));
      $sqlQuery = $mysqli->query("SELECT * FROM tbteacherlistoflessons where Numb ='$sumoftwonumbers' AND Code='$code'") or die($mysqli->error);

    ?>
          
    <!-- Embed
    ============================================= -->
    <embed  src="uploaded/<?php echo $filelocation;?>" type="application/pdf" width="100%" height="600px"/>
    <!-- End Embed -->
  


  <!-- Scripts -->
  <!-- Libs JS -->
<script src="../assets/libs/jquery/dist/jquery.min.js"></script>
<script src="../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/libs/odometer/odometer.min.js"></script>
<script src="../assets/libs/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="../assets/libs/magnific-popup/dist/jquery.magnific-popup.min.js"></script>
<script src="../assets/libs/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="../assets/libs/flatpickr/dist/flatpickr.min.js"></script>
<script src="../assets/libs/inputmask/dist/jquery.inputmask.min.js"></script>
<script src="../assets/libs/apexcharts/dist/apexcharts.min.js"></script>
<script src="../assets/libs/quill/dist/quill.min.js"></script>
<script src="../assets/libs/file-upload-with-preview/dist/file-upload-with-preview.min.js"></script>
<script src="../assets/libs/dragula/dist/dragula.min.js"></script>
<script src="../assets/libs/bs-stepper/dist/js/bs-stepper.min.js"></script>
<script src="../assets/libs/dropzone/dist/min/dropzone.min.js"></script>
<script src="../assets/libs/jQuery.print/jQuery.print.js"></script>
<script src="../assets/libs/prismjs/prism.js"></script>
<script src="../assets/libs/prismjs/components/prism-scss.min.js"></script>
<script src="../assets/libs/%40yaireo/tagify/dist/tagify.min.js"></script>
<script src="../assets/libs/tiny-slider/dist/min/tiny-slider.js"></script>
<script src="../assets/libs/%40popperjs/core/dist/umd/popper.min.js"></script>
<script src="../assets/libs/tippy.js/dist/tippy-bundle.umd.min.js"></script>
<script src="../assets/libs/typed.js/lib/typed.min.js"></script>

<!-- clipboard -->
<script src="../../../cdnjs.cloudflare.com/ajax/libs/clipboard.js/1.5.12/clipboard.min.js"></script>


<!-- Theme JS -->
<script src="../assets/js/theme.min.js"></script>

</body>
</html>