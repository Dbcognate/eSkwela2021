   <!-- Code for student who currently logged in  -->
  <?php
    $conn1 = mysqli_connect("localhost","root","","dbcognate");
    $sql1 = mysqli_query($conn1, "SELECT * FROM tbadminloggedin ORDER BY ID DESC LIMIT 1 ");
    $print_data = mysqli_fetch_row($sql1);
    $studentlastlogin = $print_data[1];
  ?>

  <?php
  require_once('config.php');
  if(isset($_GET['page']))
  {
    $page = $_GET['page'];
  }
  else
  {
    $page = 1;
  }
  
  $num_per_page = 100;
  $start_from =($page-1)*100;
  
  $query="select * from tbteacherlistofexercises where Category = 'Activity' limit $start_from,$num_per_page";
  $result=mysqli_query($conn,$query);
   
?>

<!DOCTYPE html>
<html lang="en">


<head>
  <!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


<!-- Favicon icon-->
<link rel="shortcut icon" type="image/x-icon" href="https://codescandy.com/geeks/assets/images/favicon/favicon.ico">


<!-- Libs CSS -->
<link href="../assets/fonts/feather/feather.css" rel="stylesheet" />
<link href="../assets/libs/dragula/dist/dragula.min.css" rel="stylesheet" />
<link href="../assets/libs/%40mdi/font/css/materialdesignicons.min.css" rel="stylesheet" />
<link href="../assets/libs/prismjs/themes/prism.css" rel="stylesheet" />
<link href="../assets/libs/dropzone/dist/dropzone.css" rel="stylesheet" />
<link href="../assets/libs/magnific-popup/dist/magnific-popup.css" rel="stylesheet" />
<link href="../assets/libs/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
<link href="../assets/libs/%40yaireo/tagify/dist/tagify.css" rel="stylesheet">
<link href="../assets/libs/tiny-slider/dist/tiny-slider.css" rel="stylesheet">
<link href="../assets/libs/tippy.js/dist/tippy.css" rel="stylesheet">


<!-- Theme CSS -->
<link rel="stylesheet" href="../assets/css/theme.min.css">
  <title>Activity | eSkwela</title>
</head>

<body>
  <!-- Wrapper -->
  <div id="db-wrapper">
    <!-- Sidebar -->
    <nav class="navbar-vertical navbar">
      <div class="nav-scroller">
        <!-- Brand logo -->
        <h1 align="Center" style="background-color:white;"><strong>eSkwela</strong></h1>
        <!-- Navbar nav -->
        <ul class="navbar-nav flex-column" id="sideNavbar">
          <!-- Nav item -->
          <li class="nav-item">
            <a class="nav-link" href="Dashboard.php">
              <i class="nav-icon fe fe-home mr-2"></i>Dashboard
            </a>
          </li>
          <!-- Nav item -->
          <li class="nav-item">
            <a class="nav-link active" href="#!" data-toggle="collapse" data-target="#navCourses" aria-expanded="false"
              aria-controls="navCourses">
              <i class="nav-icon fe fe-book mr-2"></i>Courses
            </a>
            <div id="navCourses" class="collapse" data-parent="#sideNavbar">
              <ul class="nav flex-column">
                <li class="nav-item">
                  <a class="nav-link" href="Classroom.php">Classroom
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="Lessons.php">Lessons
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link active" href="Activity.php">Activity
                    </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="Quiz.php">Quiz
                    </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="Exam.php">Exam
                    </a>
                </li>
              </ul>
            </div>
          </li>
          <!-- Nav item -->
          <li class="nav-item">
            <a class="nav-link " href="#!" data-toggle="collapse" data-target="#navProfile" aria-expanded="false"
              aria-controls="navProfile">
              <i class="nav-icon fe fe-user mr-2"></i>User
            </a>
            <div id="navProfile" class="collapse " data-parent="#sideNavbar">
              <ul class="nav flex-column">
                <li class="nav-item">
                  <a class="nav-link " href="Admin.php">Admin
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link " href="Teacher.php">Instructor
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="Student.php">Students</a>
                </li>
              </ul>
            </div>
          </li>
          <!-- Nav item -->
          <li class="nav-item ">
            <div class="nav-divider">
            </div>
          </li>
          <!-- Nav item -->
          <li class="nav-item ">
            <div class="navbar-heading">Documentation </div>
          </li>
          <!-- Nav item -->
          <li class="nav-item">
            <a class="nav-link" href="https://codescandy.com/geeks/docs/index.html">
              <i class="nav-icon fe fe-clipboard mr-2"></i>Documentation
            </a>
          </li>
        </ul>
      </div>
    </nav>
    <!-- sidebar -->
    <!-- Page Content -->
    <div id="page-content">
      <div class="header">
        <!-- navbar -->
        <nav class="navbar-default navbar navbar-expand-lg">
          <a id="nav-toggle" href="#!"><i class="fe fe-menu"></i></a>
          <div class="ml-lg-3 d-none d-md-none d-lg-block">
            <h1 align="Center" style="background-color:white;"><strong>eSkwela</strong></h1>
          </div>

          <!-- Navbar nav -->
           
            <ul class="navbar-nav navbar-right-wrap ml-auto d-flex nav-top-wrap">

            <li class="dropdown ml-2">
              <a class="rounded-circle " href="#!" role="button" id="dropdownUser" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <div class="d-flex">
                    <div class="avatar avatar-md">
                      <img alt="avatar" src="../assets/images/avatar/No-profile.png" >
                    </div>
                    <div class="ml-3 lh-1">
                      <h5 class="mb-1"><?php echo $print_data[1]; ?></h5>
                      <p class="mb-0 text-success"><span class="text-dark">Status: </span>Online</p>
                    </div>
                  </div>
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownUser">
                <ul class="list-unstyled">
                  <li>
                    <a class="dropdown-item" href="profile-edit.html">
                      <i class="fe fe-user mr-2"></i>Profile
                    </a>
                  </li>
                  <li>
                    <a class="dropdown-item" href="#!">
                      <i class="fe fe-settings mr-2"></i>Settings
                    </a>
                  </li>
                </ul>
                <div class="dropdown-divider"></div>
                <ul class="list-unstyled">
                  <li>
                    <a class="dropdown-item" href="AdminLogin.php">
                      <i class="fe fe-power mr-2"></i>Sign Out
                    </a>
                  </li>
                </ul>
              </div>
            </li>
          </ul>
        </nav>
      </div>
      <!-- Page Header -->
      <!-- Container fluid -->
      <div class="container-fluid p-4">          
          <div class="row">
            <div class="col-lg-12 col-md-12 col-12">
                <!-- Card -->
                <div class="card rounded-lg">
                  <!-- Card header -->
                  <div class="card-header border-bottom-0 p-0 bg-white">
                    <div>
                      <!-- Nav -->
                      <ul class="nav nav-lb-tab" id="tab" role="tablist">
                        <li class="nav-item">
                          <a class="nav-link active" id="courses-tab" data-toggle="pill" href="#courses" role="tab" aria-controls="courses" aria-selected="true">Activity</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                  <div class="p-4 row">
                    <!-- Form -->
                    <form class="d-flex align-items-center col-12 col-md-12 col-lg-12">
                       <span class="position-absolute pl-3 search-icon">
                      <i class="fe fe-search"></i>
                      </span>
                      <input type="search" class="form-control pl-6" placeholder="Search Activity" />
                    </form>
                  </div>
                  <div>  
                    <!-- Table -->
                    <form method="POST" action="Activity.php">
                    <div class="tab-content" id="tabContent">
                      <!--Tab pane -->
                      <div class="tab-pane fade show active" id="courses" role="tabpanel" aria-labelledby="courses-tab">
                        <div class="table-responsive border-0 overflow-y-hidden">
                           <table class="table mb-0 text-nowrap">
                            <thead>
                              <tr>
                                <th scope="col" class="border-0 text-uppercase">
                                  ID
                                </th>
                                <th scope="col" class="border-0 text-uppercase">
                                  FILE NAME
                                </th>
                                <th scope="col" class="border-0 text-uppercase">
                                  TEACHER EMAIL
                                </th>
                                <th scope="col" class="border-0 text-uppercase">
                                  CODE
                                </th>
                                <th scope="col" class="border-0 text-uppercase">
                                  SECTION
                                </th>
                                <th scope="col" class="border-0 text-uppercase">
                                  ACTION
                                </th>
                                <th scope="col" class="border-0 text-uppercase"></th>
                              </tr>
                            </thead>
                            <tbody>
                            <?php while($row = mysqli_fetch_assoc($result)){?>
                              <tr>
                                <td class="align-middle border-top-0">
                                  <div class="d-flex align-items-center">
                                    <h5 class="mb-0"><?php echo $row['LessonID']; ?></h5>
                                  </div>
                                </td>
                                <td class="align-middle border-top-0">
                                  <div class="d-flex align-items-center">
                                    <h5 class="mb-0"><?php echo $row['Filename']; ?></h5>
                                  </div>
                                </td>
                                <td class="align-middle border-top-0">
                                  <div class="d-flex align-items-center">
                                    <h5 class="mb-0"><?php echo $row['TeacherEmail']; ?></h5>
                                  </div>
                                </td>
                                <td class="align-middle border-top-0">
                                  <div class="d-flex align-items-center">
                                    <h5 class="mb-0"><?php echo $row['Code']; ?></h5>
                                  </div>
                                </td>
                                <td class="align-middle border-top-0">
                                  <div class="d-flex align-items-center">
                                    <h5 class="mb-0"><?php echo $row['Section']; ?></h5>
                                  </div>
                                </td>
                                <td class="align-middle border-top-0">
                                  <a href="DeleteExercises.php?del=<?php echo $row['ID']; ?>"  class="btn btn-secondary btn-sm">Delete</a>
                                </td>
                              </tr>
                              <?php }?>
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                 </form>
                </div>
              </div>
            </div>
          </div>
        </div>


  <!-- footer -->
      <!-- footer -->
    <div class="pt-5 footer bg-dark">
        <div class="container">
          <div class="row">
            <div class="col-lg-4 col-md-6 col-12">
                  <!-- about company -->
              <div class="mb-4">
                <h1 class="text-secondary"><strong>eSkwela</strong></h1>
                <div class="mt-4">
                  <p>This website is made available for school/educational purposes only and as well as to give viewers of this site additional information/examples on how to make an E-Learning Website. This website i's not to be used as a subtitute for your own projects.</p>
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
            </div>
            <div class="col-lg-2 col-md-3 col-6">
              <div class="mb-4">
                    <!-- list -->
                <h3 class="font-weight-bold mb-3 text-secondary">Support</h3>
                <ul class="list-unstyled nav nav-footer flex-column nav-x-0">
                  <li><a href="#" class="nav-link">Help and Support</a></li>
                  <li><a href="#" class="nav-link">Become Instructor</a></li>
                  <li><a href="#" class="nav-link">Get the app</a></li>
                  <li><a href="#" class="nav-link">FAQ’s</a></li>
                  <li><a href="#" class="nav-link">Tutorial</a></li>
                </ul>

              </div>
            </div>
            <div class="col-lg-3 col-md-12">
                  <!-- contact info -->
              <div class="mb-4">
                <h3 class="font-weight-bold mb-3 text-secondary">Get in touch</h3>
                <p>1600, 510 Eusebio, Pasig, 1600 Metro Manila</p>
                <p class="mb-1">Email: <a href="#">RTUeSkwela2021@gmail.com</a></p>
                <p>Phone: <span class="text-dark font-weight-semi-bold">(000) 123 456 789</span></p>

              </div>
            </div>
          </div>
          <div class="row align-items-center no-gutters border-top py-2 mt-6">
            <!-- Desc -->
            <div class="col-lg-4 col-md-5 col-12">
                <span>© 2021 eSkwela. All Rights Reserved</span>
                </div>

              <!-- Links -->
            <div class="col-12 col-md-7 col-lg-8 d-md-flex justify-content-end">
                <nav class="nav nav-footer">
                    <a class="nav-link pl-0" href="#!">Privacy Policy</a>
                    <a class="nav-link px-2 px-md-3" href="#!">Cookie Notice  </a>
                    <a class="nav-link d-none d-lg-block" href="#!">Do Not Sell My Personal Information </a>
                    <a class="nav-link" href="#!">Terms of Use</a>
                </nav>
            </div>
        </div>
        </div>
      </div>
  <!-- Script -->
  <!-- Libs JS -->
<script src="../assets/libs/jquery/dist/jquery.min.js"></script>
<script src="../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/libs/odometer/odometer.min.js"></script>
<script src="../assets/libs/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="../assets/libs/magnific-popup/dist/jquery.magnific-popup.min.js"></script>
<script src="../assets/libs/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="../assets/libs/flatpickr/dist/flatpickr.min.js"></script>
<script src="../assets/libs/inputmask/dist/jquery.inputmask.min.js"></script>
<script src="../assets/libs/apexcharts/dist/apexcharts.min.js"></script>
<script src="../assets/libs/quill/dist/quill.min.js"></script>
<script src="../assets/libs/file-upload-with-preview/dist/file-upload-with-preview.min.js"></script>
<script src="../assets/libs/dragula/dist/dragula.min.js"></script>
<script src="../assets/libs/bs-stepper/dist/js/bs-stepper.min.js"></script>
<script src="../assets/libs/dropzone/dist/min/dropzone.min.js"></script>
<script src="../assets/libs/jQuery.print/jQuery.print.js"></script>
<script src="../assets/libs/prismjs/prism.js"></script>
<script src="../assets/libs/prismjs/components/prism-scss.min.js"></script>
<script src="../assets/libs/%40yaireo/tagify/dist/tagify.min.js"></script>
<script src="../assets/libs/tiny-slider/dist/min/tiny-slider.js"></script>
<script src="../assets/libs/%40popperjs/core/dist/umd/popper.min.js"></script>
<script src="../assets/libs/tippy.js/dist/tippy-bundle.umd.min.js"></script>
<script src="../assets/libs/typed.js/lib/typed.min.js"></script>

<!-- clipboard -->
<script src="../../../cdnjs.cloudflare.com/ajax/libs/clipboard.js/1.5.12/clipboard.min.js"></script>


<!-- Theme JS -->
<script src="../assets/js/theme.min.js"></script>

</body>

</html>