<!-- Code for student who currently logged in  -->
<?php
    $conn1 = mysqli_connect("localhost","root","","dbcognate");
    $sql1 = mysqli_query($conn1, "SELECT * FROM tbstudentloggedin ORDER BY ID DESC LIMIT 1 ");
    $print_data = mysqli_fetch_row($sql1);
    $studentlastlogin = $print_data[1];
?>
<!-- Code for last lesson he open -->
    
<!-- Code for Detection who logged in  -->
<?php 
     $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "dbcognate";

    // Create connection
    $conn = new mysqli($host,$dbUsername,$dbPassword,$dbname) or die(mysqli_error($conn));  
    $sql = $conn->query("SELECT * FROM tbstudentlogin WHERE Email='$studentlastlogin'") or die($conn->error);
    $row = $sql->fetch_array();
    $name = $row['Name'];
    $email = $row['Email'];
?>
    
<?php
    if(isset($_POST['save'])){

            require 'config.php';
            $ClassCode = $_POST['classcode'];
            $sql = $conn->query("SELECT * FROM tbteacherclassroom WHERE Code='$ClassCode'") or die($conn->error);
            $row = $sql->fetch_array();
            $code = $row['Code'];
            $temail = $row['TeacherEmail'];
            $teachername = $row['TeacherName'];
            $section = $row['Section']; 
            $subject = $row['Subject']; 
            $status = "Pending";

        if (!empty($name) || !empty($email) || !empty($temail) || !empty($code) )
        {
            $host = "localhost";
            $dbUsername = "root";
            $dbPassword = "";
            $dbname = "dbcognate";
            $conn = new mysqli($host,$dbUsername,$dbPassword,$dbname);
            if (mysqli_connect_error())
            {
                die('Connect Error('.mysqli_connect_errno().')'.mysqli_connect_error());
            }
            else
            {
                $SELECT = "SELECT Email from tbstudentlist where Email='$studentlastlogin' AND Code = ? ";
                $INSERT = "INSERT Into tbstudentlist(Name,Email,Code,Subject,Section,Teacher,TeacherEmail,Status) VALUES(?,?,?,?,?,?,?,?)";
                $stmt = $conn->prepare($SELECT);
                $stmt->bind_param("s",$ClassCode);
                $stmt->execute();
                $stmt->bind_result($ClassCode);
                $stmt->store_result();
                $rnum = $stmt->num_rows;
                
                if ($rnum==0)
                {
                    $stmt->close();
                    $stmt = $conn->prepare($INSERT);
                    $stmt->bind_param("ssssssss", $name, $email, $code, $subject, $section,$teachername ,$temail,$status);
                    $stmt->execute();
                    echo'<script type = "text/javascript"> alert("Successfully Added") </script>';
                    echo'<script type = "text/javascript"> window.location = "StudentClasses.php" ; </script>';
                }
                else
                {
                echo'<script type = "text/javascript"> alert("Already Enrolled") </script>';
                echo'<script type = "text/javascript"> window.location = "StudentClasses.php" ; </script>';
                }
                $stmt->close();
                $conn->close();
            }
            
        }
    }

?>