<!-- DELETE USER Student Code here !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! -->
<?php
session_start();

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "dbcognate";

// Create connection
$conn = new mysqli($host,$dbUsername,$dbPassword,$dbname) or die(mysqli_error($conn));
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// sql to delete a record

if(isset($_GET['del'])){
	$ID = $_GET['del'];
	$sql = $conn->query("DELETE FROM tbteacherlistoflessons WHERE ID='$ID'") or die($conn->error);
	$_SESSION['message']="Record has been Deleted!";
	$_SESSION['message_type']="danger";
	
	header("location: TeacherList-of-Lessons.php");
}


$conn->close();

?> 
