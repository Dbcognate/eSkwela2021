<?php
session_start();
	$host = "localhost";
	$dbUsername = "root";
	$dbPassword = "";
	$dbname = "dbcognate";
	
	// Create connection
	$conn = new mysqli($host,$dbUsername,$dbPassword,$dbname) or die(mysqli_error($conn));
	
	if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
	}
	
	if(isset($_GET['view'])){
	$ID = $_GET['view'];
	
	$sql = $conn->query("SELECT * FROM tbteacherclassroom WHERE ID='$ID'") or die($conn->error);
	
		$row = $sql->fetch_array();
		$id = $row['ID'];
		$name = $row['Code'];
		$email = $row['Subject'];
		$password = $row['Section'];
		$confirm = $row['TeacherEmail'];
		$teachername = $row['TeacherName'];
	
		if (!empty($name) || !empty($email) || !empty($password) || !empty($confirm) )
		{
			$host = "localhost";
			$dbUsername = "root";
			$dbPassword = "";
			$dbname = "dbcognate";
		
			$hello = new mysqli($host,$dbUsername,$dbPassword,$dbname);
			
			if (mysqli_connect_error())
			{
				die('Connect Error('.mysqli_connect_errno().')'.mysqli_connect_error());
			}
			else
			{
				$SELECT = "SELECT TeacherEmail from tblviewedroom where TeacherEmail = ? ";
				$INSERT = "INSERT Into tblviewedroom(Code,Subject,Section,TeacherEmail,Teacher)values(?,?,?,?,?)";
				
				$stmt = $hello->prepare($SELECT);
				$stmt->bind_param("s",$email);
				$stmt->execute();
				$stmt->bind_result($email);
				$stmt->store_result();
				$rnum = $stmt->num_rows;

				$stmt = $hello->prepare($INSERT);
				$stmt->bind_param("sssss", $name, $email, $password, $confirm,$teachername);
				$stmt->execute();

				$stmt->close();
				$hello->close();
				echo'<script type = "text/javascript"> window.location = "TeacherList-of-Lessons.php" ; </script>';
			}
			
		}
		else
		{
			echo'<script type = "text/javascript"> alert("Error") </script>';
		}
	
	
}
?>