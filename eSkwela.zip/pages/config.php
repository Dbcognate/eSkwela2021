<?php
session_start();
$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "dbcognate";

// Create connection
$conn = new mysqli($host,$dbUsername,$dbPassword,$dbName) or die(mysqli_error($conn));

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

?>