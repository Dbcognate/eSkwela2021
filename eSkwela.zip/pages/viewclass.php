	<!-- Code for student who currently logged in  -->
		<?php
			$conn1 = mysqli_connect("localhost","root","","dbcognate");
			$sql1 = mysqli_query($conn1, "SELECT * FROM tbstudentloggedin ORDER BY ID DESC LIMIT 1 ");
			$print_data = mysqli_fetch_row($sql1);
			$studentlastlogin = $print_data[1];
		?>
	<!-- Code for last lesson he open -->
	
<?php
session_start();
	$host = "localhost";
	$dbUsername = "root";
	$dbPassword = "";
	$dbname = "dbcognate";
	
	// Create connection
	$conn = new mysqli($host,$dbUsername,$dbPassword,$dbname) or die(mysqli_error($conn));
	
	if ($conn->connect_error) {
	die("Connection failed: " . $conn->connect_error);
	}
	
	if(isset($_GET['view'])){
	$ID = $_GET['view'];
	
	$sql = $conn->query("SELECT * FROM tbstudentlist WHERE ID='$ID'") or die($conn->error);
	
		$row = $sql->fetch_array();
		$id = $row['ID'];
		$name = $row['Code'];
		$email = $row['Subject'];
		$password = $row['Section'];
		$confirm = $row['TeacherEmail'];
		$studentlastlogin = $print_data[1];
		
		
		if (!empty($name) || !empty($email) || !empty($password) || !empty($confirm) )
		{
			$host = "localhost";
			$dbUsername = "root";
			$dbPassword = "";
			$dbname = "dbcognate";
		
			$hello = new mysqli($host,$dbUsername,$dbPassword,$dbname);
			
			if (mysqli_connect_error())
			{
				die('Connect Error('.mysqli_connect_errno().')'.mysqli_connect_error());
			}
			else
			{
				$SELECT = "SELECT TeacherEmail from tblviewclass where TeacherEmail = ? ";
				$INSERT = "INSERT Into tblviewclass(Code,Subject,Section,TeacherEmail,StudentEmail)values(?,?,?,?,?)";

				$stmt = $hello->prepare($INSERT);
				$stmt->bind_param("sssss", $name, $email, $password, $confirm, $studentlastlogin);
				$stmt->execute();

				$stmt->close();
				$hello->close();
				echo'<script type = "text/javascript"> window.location = "StudentList-of-Lessons.php" ; </script>';
			}
		}
		else
		{
			echo'<script type = "text/javascript"> alert("Error") </script>';
		}
	
	
}
?>