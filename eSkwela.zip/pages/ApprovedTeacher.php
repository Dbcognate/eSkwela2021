	<?php 
		$host = "localhost";
		$dbUsername = "root";
		$dbPassword = "";
		$dbname = "dbcognate";
		$status = "Approved";
		// Create connection
		$conn = new mysqli($host,$dbUsername,$dbPassword,$dbname) or die(mysqli_error($conn));
		

		if(isset($_GET['check'])){
		$ID = $_GET['check'];
		$sql = $conn->query("SELECT * FROM tbteacherlogin WHERE ID='$ID'") or die($conn->error);
		
		$link = mysqli_connect("localhost", "root", "", "dbcognate");
	 
		// Check connection
		if($link === false){
		die("ERROR: Could not connect. " . mysqli_connect_error());
		}
	 
		// Attempt update query execution
		$sql = "UPDATE tbteacherlogin SET Note ='$status' WHERE ID ='$ID'";
		if(mysqli_query($link, $sql)){
			echo "Records were updated successfully.";
			echo'<script type = "text/javascript"> window.location = "Teacher.php" ; </script>';
		} else {
			echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
		}
	 
		// Close connection
		mysqli_close($link);
		}
	?>