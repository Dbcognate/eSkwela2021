<?php require_once ("ControllerUserData.php");?> 





 <!-- Code for student who currently logged in  -->
  <?php
    $conn1 = mysqli_connect("localhost","root","","dbcognate");
    $sql1 = mysqli_query($conn1, "SELECT * FROM tbadminloggedin ORDER BY ID DESC LIMIT 1 ");
    $print_data = mysqli_fetch_row($sql1);
    $studentlastlogin = $print_data[1];
  ?>

<!DOCTYPE html>
<html lang="en">


<head>
  <!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


<!-- Favicon icon-->
<link rel="shortcut icon" type="image/x-icon" href="https://codescandy.com/geeks/assets/images/favicon/favicon.ico">


<!-- Libs CSS -->
<link href="../assets/fonts/feather/feather.css" rel="stylesheet" />
<link href="../assets/libs/dragula/dist/dragula.min.css" rel="stylesheet" />
<link href="../assets/libs/%40mdi/font/css/materialdesignicons.min.css" rel="stylesheet" />
<link href="../assets/libs/prismjs/themes/prism.css" rel="stylesheet" />
<link href="../assets/libs/dropzone/dist/dropzone.css" rel="stylesheet" />
<link href="../assets/libs/magnific-popup/dist/magnific-popup.css" rel="stylesheet" />
<link href="../assets/libs/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
<link href="../assets/libs/%40yaireo/tagify/dist/tagify.css" rel="stylesheet">
<link href="../assets/libs/tiny-slider/dist/tiny-slider.css" rel="stylesheet">
<link href="../assets/libs/tippy.js/dist/tippy.css" rel="stylesheet">


<!-- Theme CSS -->
<link rel="stylesheet" href="../assets/css/theme.min.css">
  <title>Dashboard | eSkwela</title>
</head>

<body>
  <!-- Wrapper -->
  <div id="db-wrapper">
    <!-- Sidebar -->
    <nav class="navbar-vertical navbar">
      <div class="nav-scroller">
        <!-- Brand logo -->
        <h1 align="Center" style="background-color:white;"><strong>eSkwela</strong></h1>
        <!-- Navbar nav -->
        <ul class="navbar-nav flex-column" id="sideNavbar">
          <!-- Nav item -->
          <li class="nav-item">
            <a class="nav-link active" href="Dashboard.php">
              <i class="nav-icon fe fe-home mr-2"></i>Dashboard
            </a>
          </li>
          <!-- Nav item -->
          <li class="nav-item">
            <a class="nav-link " href="#!" data-toggle="collapse" data-target="#navCourses" aria-expanded="false"
              aria-controls="navCourses">
              <i class="nav-icon fe fe-book mr-2"></i>Courses
            </a>
            <div id="navCourses" class="collapse" data-parent="#sideNavbar">
              <ul class="nav flex-column">
                <li class="nav-item">
                  <a class="nav-link" href="Classroom.php">Classroom
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="Lessons.php">Lessons
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="Activity.php">Activity
                    </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="Quiz.php">Quiz
                    </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="Exam.php">Exam
                    </a>
                </li>
              </ul>
            </div>
          </li>
          <!-- Nav item -->
          <li class="nav-item">
            <a class="nav-link " href="#!" data-toggle="collapse" data-target="#navProfile" aria-expanded="false"
              aria-controls="navProfile">
              <i class="nav-icon fe fe-user mr-2"></i>User
            </a>
            <div id="navProfile" class="collapse " data-parent="#sideNavbar">
              <ul class="nav flex-column">
                <li class="nav-item">
                  <a class="nav-link " href="Admin.php">Admin
                  </a>
                </li>
                <li class="nav-item">
                  <a class="nav-link " href="Teacher.php">Instructor
                  </a>
                </li>
                <li class="nav-item ">
                  <a class="nav-link" href="Student.php">Students</a>
                </li>
              </ul>
            </div>
          </li>
          <!-- Nav item -->
          <li class="nav-item ">
            <div class="nav-divider">
            </div>
          </li>
          <!-- Nav item -->
          <li class="nav-item ">
            <div class="navbar-heading">Documentation </div>
          </li>
          <!-- Nav item -->
          <li class="nav-item">
            <a class="nav-link" href="https://codescandy.com/geeks/docs/index.html">
              <i class="nav-icon fe fe-clipboard mr-2"></i>Documentation
            </a>
          </li>
        </ul>
      </div>
    </nav>
    <!-- sidebar -->
    <!-- Page Content -->
    <div id="page-content">
      <div class="header">
        <!-- navbar -->
        <nav class="navbar-default navbar navbar-expand-lg">
          <a id="nav-toggle" href="#!"><i class="fe fe-menu"></i></a>
          <div class="ml-lg-3 d-none d-md-none d-lg-block">
            <h1 align="Center" style="background-color:white;"><strong>eSkwela</strong></h1>
          </div>

          <!-- Navbar nav -->
           
            <ul class="navbar-nav navbar-right-wrap ml-auto d-flex nav-top-wrap">

            <li class="dropdown ml-2">
              <a class="rounded-circle " href="#!" role="button" id="dropdownUser" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <div class="d-flex">
                    <div class="avatar avatar-md">
                      <img alt="avatar" src="../assets/images/avatar/No-profile.png" >
                    </div>
                    <div class="ml-3 lh-1">
                      <h5 class="mb-1"><?php echo $print_data[1]; ?> </h5>
                      <p class="mb-0 text-success"><span class="text-dark">Status: </span>Online</p>
                    </div>
                  </div>
              </a>
              <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownUser">
                <ul class="list-unstyled">
                  <li>
                    <a class="dropdown-item" href="profile-edit.html">
                      <i class="fe fe-user mr-2"></i>Profile
                    </a>
                  </li>
                  <li>
                    <a class="dropdown-item" href="#!">
                      <i class="fe fe-settings mr-2"></i>Settings
                    </a>
                  </li>
                </ul>
                <div class="dropdown-divider"></div>
                <ul class="list-unstyled">
                  <li>
                    <a class="dropdown-item" href="AdminLogin.php">
                      <i class="fe fe-power mr-2"></i>Sign Out
                    </a>
                  </li>
                </ul>
              </div>
            </li>
          </ul>
        </nav>
      </div>
      <!-- Page Header -->
      <!-- Container fluid -->
      <div class="container-fluid p-4">
          <div class="row">
            <div class="col-lg-12 col-md-12 col-12">
              <div class="border-bottom pb-4 mb-4 d-lg-flex justify-content-between align-items-center">
                <div>
                  <h1 class="mb-0 h2 font-weight-bold">Dashboard</h1>
                </div>
              </div>
            </div>
          </div>

    <!--- Teachers Pending Count -->
  <?php
  $servername ="localhost";
  $username ="root";
  $password ="";
  $dbname="dbcognate";

  $con =mysqli_connect($servername,$username,$password,$dbname);
  $sql = "SELECT count(ID) AS total FROM tbteacherlogin WHERE Note='Pending'";
  $results = mysqli_query($con,$sql);
  $values = mysqli_fetch_assoc($results);
  $notificationscount=$values['total'];
  ?>
  
  
  <!--- List  of Students Count -->
  <?php
  $servername ="localhost";
  $username ="root";
  $password ="";
  $dbname="dbcognate";

  $con1 =mysqli_connect($servername,$username,$password,$dbname);
  $sql1 = "SELECT count(ID) AS total FROM tbstudentlogin";
  $results1 = mysqli_query($con1,$sql1);
  $values1 = mysqli_fetch_assoc($results1);
  $studentnotifications=$values1['total'];
  ?>
  
  
  <!--- List Teachers Count -->
  <?php
  $servername ="localhost";
  $username ="root";
  $password ="";
  $dbname="dbcognate";

  $con2 =mysqli_connect($servername,$username,$password,$dbname);
  $sql2 = "SELECT count(ID) AS total FROM tbteacherlogin";
  $results2 = mysqli_query($con2,$sql2);
  $values2 = mysqli_fetch_assoc($results2);
  $teacherscount=$values2['total'];
  ?>
  
  <!--- List Lesson Count -->
  <?php
  $servername ="localhost";
  $username ="root";
  $password ="";
  $dbname="dbcognate";

  $con3 =mysqli_connect($servername,$username,$password,$dbname);
  $sql3 = "SELECT count(ID) AS total FROM tbteacherlistoflessons";
  $results3 = mysqli_query($con3,$sql3);
  $values3 = mysqli_fetch_assoc($results3);
  $lessoncount=$values3['total'];
  ?>
  
  
  <!--- List Exercises Count -->
  <?php
  $servername ="localhost";
  $username ="root";
  $password ="";
  $dbname="dbcognate";

  $con4 =mysqli_connect($servername,$username,$password,$dbname);
  $sql4 = "SELECT count(ID) AS total FROM tbteacherlistofexercises";
  $results4 = mysqli_query($con4,$sql4);
  $values4 = mysqli_fetch_assoc($results4);
  $exercisescount=$values4['total'];
  ?>
  
  
  <!--- List Classroom Count -->
  <?php
  $servername ="localhost";
  $username ="root";
  $password ="";
  $dbname="dbcognate";

  $con5 =mysqli_connect($servername,$username,$password,$dbname);
  $sql5 = "SELECT count(ID) AS total FROM tbteacherclassroom";
  $results5 = mysqli_query($con5,$sql5);
  $values5 = mysqli_fetch_assoc($results5);
  $classroomcount=$values5['total'];
  ?>
  
  <!--- List Admin Count -->
  <?php
  $servername ="localhost";
  $username ="root";
  $password ="";
  $dbname="dbcognate";

  $con6 =mysqli_connect($servername,$username,$password,$dbname);
  $sql6 = "SELECT count(ID) AS total FROM tbladminlogin";
  $results6 = mysqli_query($con6,$sql6);
  $values6 = mysqli_fetch_assoc($results6);
  $admincount=$values6['total'];
  ?>
  
  
  <!--- List Takers Count -->
  <?php
  $servername ="localhost";
  $username ="root";
  $password ="";
  $dbname="dbcognate";

  $con7 =mysqli_connect($servername,$username,$password,$dbname);
  $sql7 = "SELECT count(ID) AS total FROM tblstudenttakers";
  $results7 = mysqli_query($con7,$sql7);
  $values7 = mysqli_fetch_assoc($results7);
  $takerscount=$values7['total'];
  ?>


   <!-- Dashboard -->

          
          <div class="row">
            <div class="col-xl-3 col-lg-6 col-md-12 col-12">
              <!-- Card -->
              <div class="card mb-4">
                <!-- Card body -->
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-between mb-3 lh-1">
                    <div>
                      <span class="font-size-xs text-uppercase font-weight-semi-bold">Students</span>
                    </div>
                    <div>
                      <span class=" fe fe-users font-size-lg text-primary"></span>
                    </div>
                  </div>
                  <h2 class="font-weight-bold mb-1">
                    <?php echo $studentnotifications; ?>
                  </h2>
                  <span class="text-success font-weight-semi-bold"><i class="fe fe-trending-up mr-1"></i>+1</span>
                  <span class="ml-1 font-weight-medium">Number of Students</span>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-12 col-12">
              <!-- Card -->
              <div class="card mb-4">
                <!-- Card body -->
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-between mb-3 lh-1">
                    <div>
                      <span class="font-size-xs text-uppercase font-weight-semi-bold">Instructor</span>
                    </div>
                    <div>
                      <span class=" fe fe-user-check font-size-lg text-primary"></span>
                    </div>
                  </div>
                  <h2 class="font-weight-bold mb-1">
                    <?php echo $teacherscount; ?>
                  </h2>
                  <span class="text-success font-weight-semi-bold"><i class="fe fe-trending-up mr-1"></i>+1</span>
                  <span class="ml-1 font-weight-medium">Number of Instructor</span>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-12 col-12">
              <!-- Card -->
              <div class="card mb-4">
                <!-- Card body -->
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-between mb-3 lh-1">
                    <div>
                      <span class="font-size-xs text-uppercase font-weight-semi-bold">Admin</span>
                    </div>
                    <div>
                      <span class=" fe fe-user-check font-size-lg text-primary"></span>
                    </div>
                  </div>
                  <h2 class="font-weight-bold mb-1">
                    <?php echo $admincount; ?>
                  </h2>
                  <span class="text-success font-weight-semi-bold"><i class="fe fe-trending-up mr-1"></i>+1</span>
                  <span class="ml-1 font-weight-medium">Number of Admin</span>
                </div>
              </div>
            </div>
             <div class="col-xl-3 col-lg-6 col-md-12 col-12">
              <!-- Card -->
              <div class="card mb-4">
                <!-- Card body -->
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-between mb-3 lh-1">
                    <div>
                      <span class="font-size-xs text-uppercase font-weight-semi-bold">Student Takers</span>
                    </div>
                    <div>
                      <span class=" fe fe-users font-size-lg text-primary"></span>
                    </div>
                  </div>
                  <h2 class="font-weight-bold mb-1">
                    <?php echo $takerscount; ?>
                  </h2>
                  <span class="text-success font-weight-semi-bold"><i class="fe fe-trending-up mr-1"></i>+1</span>
                  <span class="ml-1 font-weight-medium">Number of Takers</span>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-12 col-12">
              <!-- Card -->
              <div class="card mb-4">
                <!-- Card body -->
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-between mb-3 lh-1">
                    <div>
                      <span class="font-size-xs text-uppercase font-weight-semi-bold">Courses</span>
                    </div>
                    <div>
                      <span class=" fe fe-book-open font-size-lg text-primary"></span>
                    </div>
                  </div>
                  <h2 class="font-weight-bold mb-1">
                    <?php echo $classroomcount; ?>
                  </h2>
                  <span class="text-success font-weight-semi-bold"><i class="fe fe-trending-up mr-1"></i>+1</span>
                  <span class="ml-1 font-weight-medium">Number of Courses</span>
                </div>
              </div>
            </div>
             <div class="col-xl-3 col-lg-6 col-md-12 col-12">
              <!-- Card -->
              <div class="card mb-4">
                <!-- Card body -->
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-between mb-3 lh-1">
                    <div>
                      <span class="font-size-xs text-uppercase font-weight-semi-bold">Lessons</span>
                    </div>
                    <div>
                      <span class=" fe fe-book-open font-size-lg text-primary"></span>
                    </div>
                  </div>
                  <h2 class="font-weight-bold mb-1">
                    <?php echo $lessoncount; ?>
                  </h2>
                  <span class="text-success font-weight-semi-bold"><i class="fe fe-trending-up mr-1"></i>+1</span>
                  <span class="ml-1 font-weight-medium">Number of Lessons</span>
                </div>
              </div>
            </div>
             <div class="col-xl-3 col-lg-6 col-md-12 col-12">
              <!-- Card -->
              <div class="card mb-4">
                <!-- Card body -->
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-between mb-3 lh-1">
                    <div>
                      <span class="font-size-xs text-uppercase font-weight-semi-bold">Exercises</span>
                    </div>
                    <div>
                      <span class=" fe fe-book-open font-size-lg text-primary"></span>
                    </div>
                  </div>
                  <h2 class="font-weight-bold mb-1">
                    <?php echo $exercisescount; ?>
                  </h2>
                  <span class="text-success font-weight-semi-bold"><i class="fe fe-trending-up mr-1"></i>+1</span>
                  <span class="ml-1 font-weight-medium">Number of Exercises</span>
                </div>
              </div>
            </div>
            <div class="col-xl-3 col-lg-6 col-md-12 col-12">
              <!-- Card -->
              <div class="card mb-4">
                <!-- Card body -->
                <div class="card-body">
                  <div class="d-flex align-items-center justify-content-between mb-3 lh-1">
                    <div>
                      <span class="font-size-xs text-uppercase font-weight-semi-bold">Request</span>
                    </div>
                    <div>
                      <span class=" fe fe-book-open font-size-lg text-primary"></span>
                    </div>
                  </div>
                  <h2 class="font-weight-bold mb-1">
                    <?php echo $notificationscount; ?>
                  </h2>
                  <span class="text-success font-weight-semi-bold"><i class="fe fe-trending-up mr-1"></i>+1</span>
                  <span class="ml-1 font-weight-medium">Number of Requests</span>
                </div>
              </div>
            </div>
          </div>
           <div class="row">
            <div class="col-xl-8 col-lg-12 col-md-12 col-12">
              <!-- Card -->
              <div class="card mb-4">
                <!-- Card header -->
                <div class="card-header align-items-center card-header-height d-flex justify-content-between align-items-center">
                  <div>
                    <h4 class="mb-0">Stats</h4>
                  </div>
                  <div>
                    <div class="dropdown dropleft">
                      <a class="text-muted text-decoration-none" href="#!" role="button" id="courseDropdown1"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fe fe-more-vertical"></i>
                      </a>
                      <div class="dropdown-menu" aria-labelledby="courseDropdown1">
                        <span class="dropdown-header">Settings</span>
                        <a class="dropdown-item" href="#!"><i
                            class="fe fe-external-link dropdown-item-icon "></i>Export</a>
                        <a class="dropdown-item" href="#!"><i class="fe fe-mail dropdown-item-icon "></i>Email
                          Report</a>
                        <a class="dropdown-item" href="#!"><i
                            class="fe fe-download dropdown-item-icon "></i>Download</a>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Card body -->
                <div class="card-body">
                  <!-- Earning chart -->
                  <div id="earning" class="apex-charts"></div>
                </div>
              </div>
            </div>
            <div class="col-xl-4 col-lg-12 col-md-12 col-12">
              <!-- Card -->
              <div class="card mb-4">
                <!-- Card header -->
                <div class="card-header align-items-center card-header-height  d-flex justify-content-between align-items-center">
                  <div>
                    <h4 class="mb-0">Traffic</h4>
                  </div>
                  <div>
                    <div class="dropdown dropleft">
                      <a class="text-muted text-decoration-none" href="#!" role="button" id="courseDropdown2"
                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fe fe-more-vertical"></i>
                      </a>
                      <div class="dropdown-menu" aria-labelledby="courseDropdown2">
                        <span class="dropdown-header">Settings</span>
                        <a class="dropdown-item" href="#!"><i
                            class="fe fe-external-link dropdown-item-icon "></i>Export</a>
                        <a class="dropdown-item" href="#!"><i class="fe fe-mail dropdown-item-icon "></i>Email
                          Report</a>
                        <a class="dropdown-item" href="#!"><i
                            class="fe fe-download dropdown-item-icon "></i>Download</a>
                      </div>
                    </div>
                  </div>
                </div>
                <!-- Card body -->
                <div class="card-body">
                  <div id="traffic" class="apex-charts d-flex justify-content-center"></div>
                </div>
              </div>
            </div>
          </div>
        </div>

  <!-- footer -->
      <!-- footer -->
    <div class="pt-5 footer bg-dark">
        <div class="container">
          <div class="row">
            <div class="col-lg-4 col-md-6 col-12">
                  <!-- about company -->
              <div class="mb-4">
                <h1 class="text-secondary"><strong>eSkwela</strong></h1>
                <div class="mt-4">
                  <p>This website is made available for school/educational purposes only and as well as to give viewers of this site additional information/examples on how to make an E-Learning Website. This website i's not to be used as a subtitute for your own projects.</p>
                </div>
              </div>
            </div>
            <div class="col-lg-2 col-md-3 col-6">
            </div>
            <div class="col-lg-2 col-md-3 col-6">
              <div class="mb-4">
                    <!-- list -->
                <h3 class="font-weight-bold mb-3 text-secondary">Support</h3>
                <ul class="list-unstyled nav nav-footer flex-column nav-x-0">
                  <li><a href="#" class="nav-link">Help and Support</a></li>
                  <li><a href="#" class="nav-link">Become Instructor</a></li>
                  <li><a href="#" class="nav-link">Get the app</a></li>
                  <li><a href="#" class="nav-link">FAQ’s</a></li>
                  <li><a href="#" class="nav-link">Tutorial</a></li>
                </ul>

              </div>
            </div>
            <div class="col-lg-3 col-md-12">
                  <!-- contact info -->
              <div class="mb-4">
                <h3 class="font-weight-bold mb-3 text-secondary">Get in touch</h3>
                <p>1600, 510 Eusebio, Pasig, 1600 Metro Manila</p>
                <p class="mb-1">Email: <a href="#">RTUeSkwela2021@gmail.com</a></p>
                <p>Phone: <span class="text-dark font-weight-semi-bold">(000) 123 456 789</span></p>

              </div>
            </div>
          </div>
          <div class="row align-items-center no-gutters border-top py-2 mt-6">
            <!-- Desc -->
            <div class="col-lg-4 col-md-5 col-12">
                <span>© 2021 eSkwela. All Rights Reserved</span>
                </div>

              <!-- Links -->
            <div class="col-12 col-md-7 col-lg-8 d-md-flex justify-content-end">
                <nav class="nav nav-footer">
                    <a class="nav-link pl-0" href="#!">Privacy Policy</a>
                    <a class="nav-link px-2 px-md-3" href="#!">Cookie Notice  </a>
                    <a class="nav-link d-none d-lg-block" href="#!">Do Not Sell My Personal Information </a>
                    <a class="nav-link" href="#!">Terms of Use</a>
                </nav>
            </div>
        </div>
        </div>
      </div>
  <!-- Script -->
  <!-- Libs JS -->
<script src="../assets/libs/jquery/dist/jquery.min.js"></script>
<script src="../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/libs/odometer/odometer.min.js"></script>
<script src="../assets/libs/jquery-slimscroll/jquery.slimscroll.min.js"></script>
<script src="../assets/libs/magnific-popup/dist/jquery.magnific-popup.min.js"></script>
<script src="../assets/libs/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="../assets/libs/flatpickr/dist/flatpickr.min.js"></script>
<script src="../assets/libs/inputmask/dist/jquery.inputmask.min.js"></script>
<script src="../assets/libs/apexcharts/dist/apexcharts.min.js"></script>
<script src="../assets/libs/quill/dist/quill.min.js"></script>
<script src="../assets/libs/file-upload-with-preview/dist/file-upload-with-preview.min.js"></script>
<script src="../assets/libs/dragula/dist/dragula.min.js"></script>
<script src="../assets/libs/bs-stepper/dist/js/bs-stepper.min.js"></script>
<script src="../assets/libs/dropzone/dist/min/dropzone.min.js"></script>
<script src="../assets/libs/jQuery.print/jQuery.print.js"></script>
<script src="../assets/libs/prismjs/prism.js"></script>
<script src="../assets/libs/prismjs/components/prism-scss.min.js"></script>
<script src="../assets/libs/%40yaireo/tagify/dist/tagify.min.js"></script>
<script src="../assets/libs/tiny-slider/dist/min/tiny-slider.js"></script>
<script src="../assets/libs/%40popperjs/core/dist/umd/popper.min.js"></script>
<script src="../assets/libs/tippy.js/dist/tippy-bundle.umd.min.js"></script>
<script src="../assets/libs/typed.js/lib/typed.min.js"></script>

<!-- clipboard -->
<script src="../../../cdnjs.cloudflare.com/ajax/libs/clipboard.js/1.5.12/clipboard.min.js"></script>


<!-- Theme JS -->
<script src="../assets/js/theme.min.js"></script>

</body>

</html>