<!-- DELETE USER Student Code here !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! -->
<?php
session_start();

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "dbcognate";

// Create connection
$conn = new mysqli($host,$dbUsername,$dbPassword,$dbname) or die(mysqli_error($conn));
// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// sql to delete a record

if(isset($_GET['del'])){
	$ID = $_GET['del'];
	
	// Select from Code
	$sql1 = $conn->query("SELECT * FROM tbteacherclassroom WHERE ID='$ID'") or die($conn->error);
	$row = $sql1->fetch_array();			
	$code = $row['Code'];
	
	// delete from classroom
	$sql2 = $conn->query("DELETE FROM tbteacherclassroom WHERE ID='$ID'") or die($conn->error);
	
	// delete from exercises
	$sql3 = $conn->query("DELETE FROM tbteacherlistofexercises WHERE Code='$code'") or die($conn->error);
	
	// delete from lesson
	$sql4 = $conn->query("DELETE FROM tbteacherlistoflessons WHERE Code='$code'") or die($conn->error);
	
	// delete from studentlist
	$sql5 = $conn->query("DELETE FROM tbstudentlist WHERE Code='$code'") or die($conn->error);
	
	// delete from studentakers
	$sql6 = $conn->query("DELETE FROM tblstudenttakers WHERE Code='$code'") or die($conn->error);
	
	$_SESSION['message']="Record has been Deleted!";
	$_SESSION['message_type']="danger";
	
	header("location: TeacherClassroom.php");
}


$conn->close();

?> 
