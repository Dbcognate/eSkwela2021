-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2021 at 04:20 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbcognate`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbadminloggedin`
--

CREATE TABLE `tbadminloggedin` (
  `ID` int(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbadminloggedin`
--

INSERT INTO `tbadminloggedin` (`ID`, `Email`, `Password`) VALUES
(1, 'jea@gmail.com', 'jea'),
(2, 'lloydobligado@gmail.com', 'lloyd'),
(3, 'lloydobligado@gmail.com', 'lloyd'),
(4, 'Lloydobligado@gmail.com', 'lloyd'),
(5, 'Lloydobligado@gmail.com', '$2y$10$LqGBbOsgM662QsHIzS2ZeON/ZKifOI6OSm6mzyDXucQ'),
(6, 'Lloydobligado@gmail.com', 'lloyd'),
(7, 'Lloydobligado@gmail.com', 'lloyd'),
(8, 'Lloydobligado@gmail.com', 'lloyd'),
(9, 'adrianpaano@gmail.com', 'Adrian'),
(10, 'adrianpaano@gmail.com', 'adrian'),
(11, 'adrianpaano@gmail.com', 'adrian'),
(12, 'adrianpaano@gmail.com', 'adrian'),
(13, 'adrianpaano@gmail.com', 'adrian'),
(14, 'adrianpaano@gmail.com', 'adrian'),
(15, 'adrianpaano@gmail.com', 'adrian'),
(16, 'adrianpaano@gmail.com', 'adrian'),
(17, 'adrianpaano@gmail.com', 'adrian'),
(18, 'adrianpaano@gmail.com', 'adrian'),
(19, 'adrianpaano@gmail.com', 'adrianpaano'),
(20, 'adrianpaano@gmail.com', 'adrianpaano'),
(21, 'adrianpaano@gmail.com', 'adrianpaano'),
(22, 'munzonricardo646@gmail.com', 'ricardomunzon'),
(23, 'munzonricardo646@gmail.com', 'ricardomunzon'),
(24, 'munzonricardo646@gmail.com', 'ricardomunzon'),
(25, 'munzonricardo646@gmail.com', 'ricardomunzon'),
(26, 'munzonricardo646@gmail.com', 'ricardomunzon'),
(27, 'adrianpaano@gmail.com', 'adrian'),
(28, 'adrianpaano@gmail.com', 'adrian'),
(29, 'adrianpaano@gmail.com', 'adrianpaano'),
(30, 'munzonricardo646@gmail.com', 'ricardomunzon'),
(31, 'adrianpaano@gmail.com', 'adrianpaano'),
(32, 'adrianpaano@gmail.com', 'adrianpaano'),
(33, 'adrianpaano@gmail.com', 'adrianpaano'),
(34, 'adrianpaano@gmail.com', 'adrianpaano');

-- --------------------------------------------------------

--
-- Table structure for table `tbladminlogin`
--

CREATE TABLE `tbladminlogin` (
  `ID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Code` mediumint(50) NOT NULL,
  `VerificationStatus` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbladminlogin`
--

INSERT INTO `tbladminlogin` (`ID`, `Name`, `Email`, `Password`, `Code`, `VerificationStatus`) VALUES
(1, 'Adrian Paano', 'Adrian@gmail.com', 'Adrian', 0, 'Verified'),
(2, 'Gino Escalante', 'gino@gmail.com', 'gino', 0, 'Verified'),
(3, 'Owen Adizas', 'owen@gmail.com', 'owen', 0, 'Verified'),
(4, 'Christian Del Rosario', 'christian@gmail.com', 'christian', 0, 'Verified'),
(5, 'Mariel Torres', 'Mariel@gmail.com', 'Mariel', 0, 'Verified'),
(6, 'Ranel Rodriguez', 'Ranel@gmail.com', 'Ranel', 0, 'Verified'),
(7, 'Rica Espiritu', 'Rica@gmail.com', 'Rica', 0, 'Verified'),
(8, 'Jayleen Cabanting', 'jayleen@gmail.com', 'jayleen', 0, 'Verified'),
(9, 'Jea Munez', 'jea@gmail.com', 'jea', 0, 'Verified'),
(10, 'Lloyd obligado', 'Lloydobligado@gmail.com', '$2y$10$AdyXhLiIsh610ZoW5PTKhe4g7UlktLDzSZAb/UAwuCr', 0, 'verified'),
(15, 'Adrian Paano', 'adrianpaano@gmail.com', '$2y$10$1cYeDYFZitbngCMordjJdOFYsWSBWn/oWAf0gLp5KCO6LVFCHNxMC', 0, 'verified');

-- --------------------------------------------------------

--
-- Table structure for table `tblstudenttakers`
--

CREATE TABLE `tblstudenttakers` (
  `ID` int(11) NOT NULL,
  `LessonID` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Remarks` varchar(50) NOT NULL,
  `Filename` varchar(255) NOT NULL,
  `Code` varchar(50) NOT NULL,
  `Section` varchar(50) NOT NULL,
  `TeacherEmail` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblstudenttakers`
--

INSERT INTO `tblstudenttakers` (`ID`, `LessonID`, `Name`, `Email`, `Remarks`, `Filename`, `Code`, `Section`, `TeacherEmail`) VALUES
(1, '1', 'Lloyd Obligado', 'lloyd@gmail.com', 'Done', 'Activity  - Multisim Combinational 1.pdf', 'AH12A8', 'CPE307-A', 'Tesla@gmail.com'),
(2, '1', 'Rica Espiritu', 'rica@gmail.com', 'Done', 'Activity  - Multisim Combinational 1.pdf', '82BDIH', 'CPE307-B', 'Ohm@gmail.com'),
(3, '1', 'Jennie Garcia', 'jennie@gmail.com', 'Done', 'Activity  - Multisim Combinational 1.pdf', '837JDM', 'CPE307-C', 'Newton@gmail.com'),
(4, '1', 'Lawrence Dolar', 'lawrence@gmail.com', 'Done', 'Activity  - Multisim Combinational 1.pdf', 'AH12A8', 'CPE307-A', 'Tesla@gmail.com'),
(5, '1', 'Kyle Ancheta', 'kyle@gmail.com', 'Done', 'Activity  - Multisim Combinational 1.pdf', '82BDIH', 'CPE307-B', 'Ohm@gmail.com'),
(6, '1', 'Lloyd Obligado', 'lloyd@gmail.com', 'Done', 'Activity - Multisim Magnitude Comparator.pdf.pdf', 'KS98WJ', 'CPE304-C', 'Newton@gmail.com'),
(7, '1', 'Rica Espiritu', 'rica@gmail.com', 'Done', 'Activity - Multisim Magnitude Comparator.pdf.pdf', 'KS98WJ', 'CPE304-A', 'Tesla@gmail.com'),
(8, '1', 'Jennie Garcia', 'jennie@gmail.com', 'Done', 'Activity - Multisim Magnitude Comparator.pdf.pdf', 'H12H3N', 'CPE304-B', 'Ohm@gmail.com'),
(9, '1', 'Lawrence Dolar', 'lawrence@gmail.com', 'Done', 'Activity - Multisim Magnitude Comparator.pdf.pdf', 'HSJ010', 'CPE304-C', 'Newton@gmail.com'),
(10, '1', 'Kyle Ancheta', 'kyle@gmail.com', 'Done', 'Activity - Multisim Magnitude Comparator.pdf', 'KS98WJ', 'CPE304-A', 'Tesla@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tblviewclass`
--

CREATE TABLE `tblviewclass` (
  `ID` int(11) NOT NULL,
  `Code` varchar(50) NOT NULL,
  `Subject` varchar(50) NOT NULL,
  `Section` varchar(50) NOT NULL,
  `TeacherEmail` varchar(50) NOT NULL,
  `StudentEmail` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblviewclass`
--

INSERT INTO `tblviewclass` (`ID`, `Code`, `Subject`, `Section`, `TeacherEmail`, `StudentEmail`) VALUES
(1, 'AH12A8', 'Computer Engineering Drafting and Design', 'CPE307-A', 'Tesla@gmail.com', 'Lloyd@gmail.com'),
(2, '82BDIH', 'Computer Engineering Drafting and Design', 'CPE307-B', 'Ohm@gmail.com', 'Lawrence@gmail.com'),
(3, '837JDM', 'Computer Engineering Drafting and Design', 'CPE307-C', 'Newton@gmail.com', 'jennie@gmail.com'),
(4, 'AH12A8', 'Computer Engineering Drafting and Design', 'CPE307-A', 'Tesla@gmail.com', 'kyle@gmail.com'),
(5, '82BDIH', 'Computer Engineering Drafting and Design', 'CPE307-B', 'Ohm@gmail.com', 'Rica@gmail.com'),
(6, '837JDM', 'Computer Engineering Drafting and Design', 'CPE307-C', 'Newton@gmail.com', 'kenneth@gmail.com'),
(7, 'AH12A8', 'Computer Engineering Drafting and Design', 'CPE307-A', 'Tesla@gmail.com', 'RB@gmail.com'),
(8, 'KS98WJ', 'Introduction to HDL', 'CPE304-A', 'Tesla@gmail.com', 'Lloyd@gmail.com'),
(9, 'H12H3N', 'Introduction to HDL', 'CPE304-B', 'Ohm@gmail.com', 'Lawrence@gmail.com'),
(10, 'HSJ010', 'Introduction to HDL', 'CPE304-C', 'Newton@gmail.com', 'jennie@gmail.com'),
(11, 'KS98WJ', 'Introduction to HDL', 'CPE304-A', 'Tesla@gmail.com', 'kyle@gmail.com'),
(12, 'H12H3N', 'Introduction to HDL', 'CPE304-B', 'Ohm@gmail.com', 'Rica@gmail.com'),
(13, 'HSJ010', 'Introduction to HDL', 'CPE304-C', 'Newton@gmail.com', 'kenneth@gmail.com'),
(14, 'KS98WJ', 'Introduction to HDL', 'CPE304-A', 'Tesla@gmail.com', 'RB@gmail.com'),
(15, 'AH12A8', 'Computer Engineering Drafting and Design', 'CPE307-A', 'Tesla@gmail.com', 'escalante@gmail.com'),
(16, 'AH12A8', 'Computer Engineering Drafting and Design', 'CPE307-A', 'Tesla@gmail.com', 'escalante@gmail.com'),
(17, 'AH12A8', 'Computer Engineering Drafting and Design', 'CPE307-A', 'Tesla@gmail.com', 'escalante@gmail.com'),
(18, 'AH12A8', 'Computer Engineering Drafting and Design', 'CPE307-A', 'Tesla@gmail.com', 'escalante@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tblviewedroom`
--

CREATE TABLE `tblviewedroom` (
  `ID` int(11) NOT NULL,
  `Code` varchar(50) NOT NULL,
  `Subject` varchar(50) NOT NULL,
  `Section` varchar(50) NOT NULL,
  `Teacher` varchar(50) NOT NULL,
  `TeacherEmail` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblviewedroom`
--

INSERT INTO `tblviewedroom` (`ID`, `Code`, `Subject`, `Section`, `Teacher`, `TeacherEmail`) VALUES
(1, 'AH12A8', 'Computer Engineering Drafting and Design', 'CPE307-A', 'Nikola Tesla', 'Tesla@gmail.com'),
(2, '82BDIH', 'Computer Engineering Drafting and Design', 'CPE307-B', 'George Ohm', 'Ohm@gmail.com'),
(3, '837JDM', 'Computer Engineering Drafting and Design', 'CPE307-C', 'Isaac Newton', 'Newton@gmail.com'),
(4, 'KS98WJ', 'Introduction to HDL', 'CPE304-A', 'Nikola Tesla', 'Tesla@gmail.com'),
(5, 'H12H3N', 'Introduction to HDL', 'CPE304-B', 'George Ohm', 'Ohm@gmail.com'),
(6, 'HSJ010', 'Introduction to HDL', 'CPE304-C', 'Isaac Newton', 'Newton@gmail.com'),
(7, 'AH12A8', 'Computer Engineering Drafting and Design', 'CPE307-A', 'Nikola Tesla', 'Tesla@gmail.com'),
(8, 'vy', 'gh', 'guj', 'Lloyd obligado', 'lloydobligado@gmail.com'),
(9, 'AH12A8', 'Computer Engineering Drafting and Design', 'CPE307-A', 'Nikola Tesla', 'Tesla@gmail.com'),
(10, 'TR56HU', 'Technopreneurship', 'CPE-301 A', 'Rick Morty ', 'munzonricardo646@gmail.com'),
(11, 'TR56HU', 'Technopreneurship', 'CPE-301 A', 'Rick Morty ', 'munzonricardo646@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbstudentlist`
--

CREATE TABLE `tbstudentlist` (
  `ID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Code` varchar(50) NOT NULL,
  `Subject` varchar(50) NOT NULL,
  `Teacher` varchar(50) NOT NULL,
  `TeacherEmail` varchar(50) NOT NULL,
  `Section` varchar(50) NOT NULL,
  `Status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbstudentlist`
--

INSERT INTO `tbstudentlist` (`ID`, `Name`, `Email`, `Code`, `Subject`, `Teacher`, `TeacherEmail`, `Section`, `Status`) VALUES
(1, 'Lloyd Obligado', 'lloyd@gmail.com', 'AH12A8', 'Computer Engineering Drafting and Design', 'Nikola Tesla', 'Tesla@gmail.com', 'CPE307-A', 'Enrolled'),
(2, 'Adrian Paano', 'adrian@gmail.com', '82BDIH', 'Computer Engineering Drafting and Design', 'George Ohm', 'Ohm@gmail.com', 'CPE307-B', 'Enrolled'),
(3, 'Jennie Garcia', 'Jennie@gmail.com', '837JDM', 'Computer Engineering Drafting and Design', 'Isaac Newton', 'Newton@gmail.com', 'CPE307-C', 'Enrolled'),
(4, 'CJ Villanueva', 'CJ@gmail.com', 'AH12A8', 'Computer Engineering Drafting and Design', 'Nikola Tesla', 'Tesla@gmail.com', 'CPE307-A', 'Enrolled'),
(5, 'Lawrence Dolar', 'Lawrence@gmail.com', '82BDIH', 'Computer Engineering Drafting and Design', 'George Ohm', 'Ohm@gmail.com', 'CPE307-B', 'Enrolled'),
(6, 'RB Reyno', 'RB@gmail.com', '837JDM', 'Computer Engineering Drafting and Design', 'Isaac Newton', 'Newton@gmail.com', 'CPE307-C', 'Enrolled'),
(7, 'Rica Espiritu', 'Rica@gmail.com', 'AH12A8', 'Computer Engineering Drafting and Design', 'Nikola Tesla', 'Tesla@gmail.com', 'CPE307-A', 'Pending'),
(8, 'Kenneth Paulino', 'Kenneth@gmail.com', '82BDIH', 'Computer Engineering Drafting and Design', 'George Ohm', 'Ohm@gmail.com', 'CPE307-B', 'Pending'),
(9, 'Kyle Ancheta', 'Kyle@gmail.com', '837JDM', 'Computer Engineering Drafting and Design', 'Isaac Newton', 'Newton@gmail.com', 'CPE307-C', 'Pending'),
(10, 'Lloyd Obligado', 'lloyd@gmail.com', 'KS98WJ', 'Introduction to HDL', 'Nikola Tesla', 'Tesla@gmail.com', 'CPE304-A', 'Enrolled'),
(11, 'Adrian Paano', 'adrian@gmail.com', 'H12H3N', 'Introduction to HDL', 'George Ohm', 'Ohm@gmail.com', 'CPE304-B', 'Enrolled'),
(12, 'Jennie Garcia', 'Jennie@gmail.com', 'HSJ010', 'Introduction to HDL', 'Isaac Newton', 'Newton@gmail.com', 'CPE304-C', 'Enrolled'),
(13, 'CJ Villanueva', 'CJ@gmail.com', 'KS98WJ', 'Introduction to HDL', 'Nikola Tesla', 'Tesla@gmail.com', 'CPE304-A', 'Enrolled'),
(14, 'Lawrence Dolar', 'Lawrence@gmail.com', 'H12H3N', 'Introduction to HDL', 'George Ohm', 'Ohm@gmail.com', 'CPE304-B', 'Enrolled'),
(15, 'RB Reyno', 'RB@gmail.com', 'HSJ010', 'Introduction to HDL', 'Isaac Newton', 'Newton@gmail.com', 'CPE304-C', 'Enrolled'),
(16, 'Rica Espiritu', 'Rica@gmail.com', 'KS98WJ', 'Introduction to HDL', 'Nikola Tesla', 'Tesla@gmail.com', 'CPE304-A', 'Enrolled'),
(17, 'Kenneth Paulino', 'Kenneth@gmail.com', 'H12H3N', 'Introduction to HDL', 'George Ohm', 'Ohm@gmail.com', 'CPE304-B', 'Enrolled'),
(18, 'Kyle Ancheta', 'Kyle@gmail.com', 'HSJ010', 'Introduction to HDL', 'Isaac Newton', 'Newton@gmail.com', 'CPE304-C', 'Enrolled'),
(19, 'Gino Escalante', 'escalante@gmail.com', 'AH12A8', 'Computer Engineering Drafting and Design', 'Nikola Tesla', 'Tesla@gmail.com', 'CPE307-A', 'Enrolled'),
(20, 'Adrian Furing Paano', 'adrianpaano@gmail.com', '82BDIH', 'Computer Engineering Drafting and Design', 'George Ohm', 'Ohm@gmail.com', 'CPE307-B', 'Pending'),
(21, 'Adrian Furing Paano', 'adrianpaano@gmail.com', 'TR56HU', 'Technopreneurship', 'Rick Morty ', 'munzonricardo646@gmail.com', 'CPE-301 A', 'Enrolled'),
(22, 'Adrian Furing Paano', 'adrianpaano@gmail.com', 'AH12A8', 'Computer Engineering Drafting and Design', 'Nikola Tesla', 'Tesla@gmail.com', 'CPE307-A', 'Enrolled');

-- --------------------------------------------------------

--
-- Table structure for table `tbstudentloggedin`
--

CREATE TABLE `tbstudentloggedin` (
  `ID` int(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbstudentloggedin`
--

INSERT INTO `tbstudentloggedin` (`ID`, `Email`, `Password`) VALUES
(1, 'lloyd@gmail.com', 'lloyd'),
(2, 'lawrence@gmail.com', 'lawrence'),
(3, 'Jennie@gmail.com', 'jennie'),
(4, 'rica@gmail.com', 'rica'),
(5, 'jea@gmail.com', 'jea'),
(6, 'rica@gmail.com', 'rica'),
(7, 'kenneth@gmail.com', 'ken'),
(8, 'Adrian@gmail.com', 'Adrian'),
(9, 'cj@gmail.com', 'cj'),
(10, 'lloyd@gmail.com', 'lloyd'),
(11, 'lloyd@gmail.com', 'lloyd'),
(12, 'lawrence@gmail.com', 'lawrence'),
(13, 'Jennie@gmail.com', 'jennie'),
(14, 'rica@gmail.com', 'rica'),
(15, 'jea@gmail.com', 'jea'),
(16, 'rica@gmail.com', 'rica'),
(17, 'kenneth@gmail.com', 'ken'),
(18, 'Adrian@gmail.com', 'Adrian'),
(19, 'cj@gmail.com', 'cj'),
(20, 'lloyd@gmail.com', 'lloyd'),
(21, 'lloyd@gmail.com', 'lloyd'),
(22, 'lawrence@gmail.com', 'lawrence'),
(23, 'Jennie@gmail.com', 'jennie'),
(24, 'rica@gmail.com', 'rica'),
(25, 'jea@gmail.com', 'jea'),
(26, 'rica@gmail.com', 'rica'),
(27, 'kenneth@gmail.com', 'ken'),
(28, 'Adrian@gmail.com', 'Adrian'),
(29, 'cj@gmail.com', 'cj'),
(30, 'lloyd@gmail.com', 'lloyd'),
(31, 'lloyd@gmail.com', 'lloyd'),
(32, 'rica@gmail.com', 'rica'),
(33, 'kenneth@gmail.com', 'ken'),
(34, 'Adrian@gmail.com', 'Adrian'),
(35, 'cj@gmail.com', 'cj'),
(36, 'lloyd@gmail.com', 'lloyd'),
(37, 'lloyd@gmail.com', 'lloyd'),
(38, 'lawrence@gmail.com', 'lawrence'),
(39, 'Jennie@gmail.com', 'jennie'),
(40, 'rica@gmail.com', 'rica'),
(41, 'jea@gmail.com', 'jea'),
(42, 'rica@gmail.com', 'rica'),
(43, 'kenneth@gmail.com', 'ken'),
(44, 'Adrian@gmail.com', 'Adrian'),
(45, 'cj@gmail.com', 'cj'),
(46, 'lloyd@gmail.com', 'lloyd'),
(47, 'lloyd@gmail.com', 'lloyd'),
(48, 'lawrence@gmail.com', 'lawrence'),
(49, 'Jennie@gmail.com', 'jennie'),
(50, 'rica@gmail.com', 'rica'),
(51, 'jea@gmail.com', 'jea'),
(52, 'rica@gmail.com', 'rica'),
(53, 'kenneth@gmail.com', 'ken'),
(54, 'Adrian@gmail.com', 'Adrian'),
(55, 'lloydobligado@gmail.com', 'lloyd'),
(56, 'escalante@gmail.com', 'gino24'),
(57, 'escalante@gmail.com', 'gino24'),
(58, 'adrianpaano@gmail.com', 'adrianpaano'),
(59, 'adrianpaano@gmail.com', 'adrianpaano'),
(60, 'adrianpaano@gmail.com', 'adrianpaano');

-- --------------------------------------------------------

--
-- Table structure for table `tbstudentlogin`
--

CREATE TABLE `tbstudentlogin` (
  `ID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Code` mediumint(50) NOT NULL,
  `Note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbstudentlogin`
--

INSERT INTO `tbstudentlogin` (`ID`, `Name`, `Email`, `Password`, `Code`, `Note`) VALUES
(1, 'Lloyd Obligado', 'lloyd@gmail.com', 'lloyd', 0, 'Verified'),
(2, 'Lawrence Dolar', 'lawrence@gmail.com', 'lawrence', 0, 'Verified'),
(3, 'Jennie Garcia', 'Jennie@gmail.com', 'jennie', 0, 'Verified'),
(4, 'Kyle Ancheta', 'kyle@gmail.com', 'kyle', 0, 'Verified'),
(5, 'Jea Munez', 'jea@gmail.com', 'jea', 0, 'Verified'),
(6, 'Rica Espiritu', 'rica@gmail.com', 'rica', 0, 'Verified'),
(7, 'Kenneth Paulino', 'kenneth@gmail.com', 'ken', 0, 'Verified'),
(8, 'Adrian Paano', 'Adrian@gmail.com', 'Adrian', 0, 'Verified'),
(9, 'CJ Villanueva', 'cj@gmail.com', 'cj', 0, 'Verified'),
(10, 'jay', 'neelyaj29@gmail.com', '$2y$10$yBntZFJyvTsSChWcR30o/u63ccH7b73I57SzTMDk0uvXc0g0snL8u', 0, 'Approved'),
(11, 'Lloyd Obligado', 'Lloydobligado@gmail.com', '$2y$10$yGpOL.AinLLDI5P3Xmim3OHnwedSQ21uOx5ugcjdHw9n8tKfoWTPa', 0, 'Approved'),
(12, 'Gino Escalante', 'escalante@gmail.com', '$2y$10$It/iROky/7prZv57QAJHhuygQ6N9dOCFbhYl4J8D9b/XDvDbwAbja', 0, 'Approved'),
(13, 'Adrian Furing Paano', 'adrianpaano@gmail.com', '$2y$10$8sYfZdObZn2JW3teCeN85e3uYw3Kc/oOAONziJFfgqxhuQZYwPwTm', 0, 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `tbteacherclassroom`
--

CREATE TABLE `tbteacherclassroom` (
  `ID` int(11) NOT NULL,
  `Code` varchar(50) NOT NULL,
  `Subject` varchar(50) NOT NULL,
  `Section` varchar(50) NOT NULL,
  `TeacherName` varchar(50) NOT NULL,
  `TeacherEmail` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbteacherclassroom`
--

INSERT INTO `tbteacherclassroom` (`ID`, `Code`, `Subject`, `Section`, `TeacherName`, `TeacherEmail`) VALUES
(1, 'AH12A8', 'Computer Engineering Drafting and Design', 'CPE307-A', 'Nikola Tesla', 'Tesla@gmail.com'),
(2, 'KS98WJ', 'Introduction to HDL', 'CPE304-A', 'Nikola Tesla', 'Tesla@gmail.com'),
(3, '837JDM', 'Computer Engineering Drafting and Design', 'CPE307-C', 'Isaac Newton', 'Newton@gmail.com'),
(4, 'HSJ010', 'Introduction to HDL', 'CPE304-C', 'Isaac Newton', 'Newton@gmail.com'),
(5, '82BDIH', 'Computer Engineering Drafting and Design', 'CPE307-B', 'George Ohm', 'Ohm@gmail.com'),
(6, 'H12H3N', 'Introduction to HDL', 'CPE304-B', 'George Ohm', 'Ohm@gmail.com'),
(7, 'vy', 'gh', 'guj', 'Lloyd obligado', 'lloydobligado@gmail.com'),
(8, 'TR56HU', 'Technopreneurship', 'CPE-301 A', 'Rick Morty ', 'munzonricardo646@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbteacherlistofexercises`
--

CREATE TABLE `tbteacherlistofexercises` (
  `ID` int(11) NOT NULL,
  `LessonID` varchar(50) NOT NULL,
  `Filename` varchar(255) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `TeacherEmail` varchar(50) NOT NULL,
  `Code` varchar(50) NOT NULL,
  `Section` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbteacherlistofexercises`
--

INSERT INTO `tbteacherlistofexercises` (`ID`, `LessonID`, `Filename`, `Category`, `TeacherEmail`, `Code`, `Section`) VALUES
(1, '1', 'Activity  - Multisim Combinational 1.pdf', 'Activity', 'Tesla@gmail.com', 'AH12A8', 'CPE307-A'),
(2, '1', 'Activity  - Multisim Combinational 1.pdf', 'Activity', 'Ohm@gmail.com', '82BDIH', 'CPE307-B'),
(3, '1', 'Activity  - Multisim Combinational 1.pdf', 'Activity', 'Newton@gmail.com', '837JDM', 'CPE307-C'),
(4, '1', 'Quiz - Multisim Magnitude Comparator.pdf', 'Quiz', 'Tesla@gmail.com', 'KS98WJ', 'CPE304-A'),
(5, '1', 'Quiz - Multisim Magnitude Comparator.pdf', 'Quiz', 'Ohm@gmail.com', 'H12H3N', 'CPE304-B'),
(6, '1', 'Quiz - Multisim Magnitude Comparator.pdf', 'Quiz', 'Newton@gmail.com', 'HSJ010', 'CPE304-C'),
(7, '1', 'Exam  - Multisim Combinational 1.pdf', 'Exam', 'Tesla@gmail.com', 'AH12A8', 'CPE307-A'),
(8, '1', 'Exam  - Multisim Combinational 1.pdf', 'Exam', 'Ohm@gmail.com', '82BDIH', 'CPE307-B'),
(9, '1', 'Exam  - Multisim Combinational 1.pdf', 'Exam', 'Newton@gmail.com', '837JDM', 'CPE307-C'),
(10, '1', 'Quiz  - Multisim Combinational 1.pdf', 'Quiz', 'Tesla@gmail.com', 'AH12A8', 'CPE307-A'),
(11, '1', 'Quiz  - Multisim Combinational 1.pdf', 'Quiz', 'Ohm@gmail.com', '82BDIH', 'CPE307-B'),
(12, '1', 'Quiz  - Multisim Combinational 1.pdf', 'Quiz', 'Newton@gmail.com', '837JDM', 'CPE307-C'),
(13, '1', 'Activity - Multisim Magnitude Comparator.pdf', 'Activity', 'Tesla@gmail.com', 'KS98WJ', 'CPE304-A'),
(14, '1', 'Activity - Multisim Magnitude Comparator.pdf', 'Activity', 'Ohm@gmail.com', 'H12H3N', 'CPE304-B'),
(15, '1', 'Activity - Multisim Magnitude Comparator.pdf', 'Activity', 'Newton@gmail.com', 'HSJ010', 'CPE304-C'),
(16, '1', 'Exam - Multisim Magnitude Comparator.pdf', 'Exam', 'Tesla@gmail.com', 'KS98WJ', 'CPE304-A'),
(17, '1', 'Exam - Multisim Magnitude Comparator.pdf', 'Exam', 'Ohm@gmail.com', 'H12H3N', 'CPE304-B'),
(18, '1', 'Exam - Multisim Magnitude Comparator.pdf', 'Exam', 'Newton@gmail.com', 'HSJ010', 'CPE304-C');

-- --------------------------------------------------------

--
-- Table structure for table `tbteacherlistoflessons`
--

CREATE TABLE `tbteacherlistoflessons` (
  `ID` int(11) NOT NULL,
  `Numb` varchar(50) NOT NULL,
  `Chapter` varchar(50) NOT NULL,
  `Title` varchar(255) NOT NULL,
  `Filename` varchar(255) NOT NULL,
  `Category` varchar(50) NOT NULL,
  `TeacherEmail` varchar(255) NOT NULL,
  `Code` varchar(50) NOT NULL,
  `Section` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbteacherlistoflessons`
--

INSERT INTO `tbteacherlistoflessons` (`ID`, `Numb`, `Chapter`, `Title`, `Filename`, `Category`, `TeacherEmail`, `Code`, `Section`) VALUES
(1, '1', 'Chapter 1', 'Multisim Combinational 1', 'Discussion - Multisim Combinational 1.pdf', 'Pdf', 'Tesla@gmail.com', 'AH12A8', 'CPE307-A'),
(2, '1', 'Chapter 2', 'Multisim Combinational 3', 'Discussion - Multisim Combinational 3.pdf', 'Pdf', 'Tesla@gmail.com', 'AH12A8', 'CPE307-A'),
(3, '1', 'Chapter 1', 'Multisim Combinational 1', 'Discussion - Multisim Combinational 1.pdf', 'Pdf', 'Ohm@gmail.com', '82BDIH', 'CPE307-B'),
(4, '1', 'Chapter 2', 'Multisim Combinational 3', 'Discussion - Multisim Combinational 3.pdf', 'Pdf', 'Ohm@gmail.com', '82BDIH', 'CPE307-B'),
(5, '1', 'Chapter 1', 'Multisim Combinational 1', 'Discussion - Multisim Combinational 1.pdf', 'Pdf', 'Newton@gmail.com', '837JDM', 'CPE307-C'),
(6, '1', 'Chapter 2', 'Multisim Combinational 3', 'Discussion - Multisim Combinational 3.pdf', 'Pdf', 'Newton@gmail.com', '837JDM', 'CPE307-C'),
(7, '1', 'Chapter 1', 'Multisim Magnitude Comparator', 'Discussion - Multisim Magnitude Comparator.pdf', 'Pdf', 'Tesla@gmail.com', 'KS98WJ', 'CPE304-A'),
(8, '1', 'Chapter 2', 'Multisim Seven Logic Gates', 'Discussion - Multisim Seven Logic gates.pdf', 'Pdf', 'Tesla@gmail.com', 'KS98WJ', 'CPE304-A'),
(9, '1', 'Chapter 1', 'Multisim Magnitude Comparator', 'Discussion - Multisim Magnitude Comparator.pdf', 'Pdf', 'Ohm@gmail.com', 'H12H3N', 'CPE304-B'),
(10, '1', 'Chapter 2', 'Multisim Seven Logic Gates', 'Discussion - Multisim Seven Logic gates.pdf', 'Pdf', 'Ohm@gmail.com', 'H12H3N', 'CPE304-B'),
(11, '1', 'Chapter 1', 'Multisim Magnitude Comparator', 'Discussion - Multisim Magnitude Comparator.pdf', 'Pdf', 'Newton@gmail.com', 'HSJ010', 'CPE304-C'),
(12, '1', 'Chapter 2', 'Multisim Seven Logic Gates', 'Discussion - Multisim Seven Logic gates.pdf', 'Pdf', 'Newton@gmail.com', 'HSJ010', 'CPE304-C'),
(13, '1', 'sds', 'sds', 'Activity  - Multisim Combinational 1.pdf', 'Pdf', 'lloydobligado@gmail.com', 'vy', 'guj');

-- --------------------------------------------------------

--
-- Table structure for table `tbteacherlogin`
--

CREATE TABLE `tbteacherlogin` (
  `ID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Code` mediumint(50) NOT NULL,
  `Note` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbteacherlogin`
--

INSERT INTO `tbteacherlogin` (`ID`, `Name`, `Email`, `Password`, `Code`, `Note`) VALUES
(1, 'Isaac Newton', 'Newton@gmail.com', 'newton', 0, 'Approved'),
(2, 'John Johnson', 'Johnson@gmail.com', 'johnson', 0, 'Pending'),
(3, 'George Ohm', 'Ohm@gmail.com', 'ohm', 0, 'Approved'),
(4, 'Nikola Tesla', 'Tesla@gmail.com', '$2y$10$w4iFCvfn.5MUmB9XCsk/zejb4jjqf7YVw.IS/KJFlbOsN3yJ7hiV.', 0, 'Approved'),
(8, 'Lloyd obligado', 'lloydobligado@gmail.com', '$2y$10$HQGEM5cKl3ncmJnA6GAjXeYTNQwmNZsONUew9jy1C06', 0, 'Approved'),
(10, 'pj699816', 'pj699816@gmail.com', '$2y$10$pu8U1tHdL8M.vEfSJguvKOmWWwuquAnXfVUjOOxtImE5F9hpaK3We', 633829, 'not verified'),
(11, 'Jennie', 'garciajenniemae97@gmail.com', '$2y$10$w4iFCvfn.5MUmB9XCsk/zejb4jjqf7YVw.IS/KJFlbOsN3yJ7hiV.', 0, 'Approved'),
(12, 'Adrian How', 'adrianpaano@gmail.com', '$2y$10$7QeilnE3Tad9aSHl2MCpGe5g4l3kV/trlUR6pdd.Gm/oBbeAJmdG.', 0, 'Approved'),
(13, 'Rick Morty ', 'munzonricardo646@gmail.com', '$2y$10$EzP1lwpEaBJ46z1P5x2EW.sAVAEDr6alls56uZSAP42YpdYJjjBae', 0, 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `tbteachersloggedin`
--

CREATE TABLE `tbteachersloggedin` (
  `ID` int(11) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbteachersloggedin`
--

INSERT INTO `tbteachersloggedin` (`ID`, `Email`, `Password`) VALUES
(1, 'Tesla@gmail.com', 'tesla'),
(2, 'Ohm@gmail.com', 'ohm'),
(3, 'Johnson@gmail.com', 'johnson'),
(4, 'Tesla@gmail.com', 'tesla'),
(5, 'Ohm@gmail.com', 'ohm'),
(6, 'Johnson@gmail.com', 'johnson'),
(7, 'Tesla@gmail.com', 'tesla'),
(8, 'Ohm@gmail.com', 'ohm'),
(9, 'Johnson@gmail.com', 'johnson'),
(10, 'Tesla@gmail.com', 'tesla'),
(11, 'Ohm@gmail.com', 'ohm'),
(12, 'Johnson@gmail.com', 'johnson'),
(13, 'Tesla@gmail.com', 'tesla'),
(14, 'Ohm@gmail.com', 'ohm'),
(15, 'Johnson@gmail.com', 'johnson'),
(16, 'Tesla@gmail.com', 'tesla'),
(17, 'Ohm@gmail.com', 'ohm'),
(18, 'Johnson@gmail.com', 'johnson'),
(19, 'Tesla@gmail.com', 'tesla'),
(20, 'Ohm@gmail.com', 'ohm'),
(21, 'Johnson@gmail.com', 'johnson'),
(22, 'Tesla@gmail.com', 'tesla'),
(23, 'Ohm@gmail.com', 'ohm'),
(24, 'Johnson@gmail.com', 'johnson'),
(25, 'Tesla@gmail.com', 'tesla'),
(26, 'Ohm@gmail.com', 'ohm'),
(27, 'Johnson@gmail.com', 'johnson'),
(28, 'Tesla@gmail.com', 'tesla'),
(29, 'Ohm@gmail.com', 'ohm'),
(30, 'Johnson@gmail.com', 'johnson'),
(31, 'Tesla@gmail.com', 'tesla'),
(32, 'Ohm@gmail.com', 'ohm'),
(33, 'Johnson@gmail.com', 'johnson'),
(34, 'Tesla@gmail.com', 'tesla'),
(35, 'Ohm@gmail.com', 'ohm'),
(36, 'Johnson@gmail.com', 'johnson'),
(37, 'Tesla@gmail.com', 'tesla'),
(38, 'Ohm@gmail.com', 'ohm'),
(39, 'Johnson@gmail.com', 'johnson'),
(40, 'Tesla@gmail.com', 'tesla'),
(49, 'lloydobligado@gmail.com', 'lloyd'),
(50, 'lloydobligado@gmail.com', 'lloyd'),
(51, 'lloydobligado@gmail.com', 'lloyd'),
(52, 'lloydobligado@gmail.com', 'lloyd'),
(53, 'garciajenniemae97@gmail.com', 'gino'),
(54, 'garciajenniemae97@gmail.com', 'gino24'),
(55, 'garciajenniemae97@gmail.com', 'gino'),
(56, 'Tesla@gmail.com', 'tesla'),
(57, 'Tesla@gmail.com', 'gino'),
(58, 'adrianpaano@gmail.com', 'Adrian'),
(59, 'adrianpaano@gmail.com', 'adrianpaano'),
(60, 'munzonricardo646@gmail.com', 'ricardomunzon'),
(61, 'munzonricardo646@gmail.com', 'ricardomunzon'),
(62, 'Ohm@gmail.com', 'ohm'),
(63, 'munzonricardo646@gmail.com', 'ricardomunzon'),
(64, 'munzonricardo646@gmail.com', 'ricardomunzon');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbadminloggedin`
--
ALTER TABLE `tbadminloggedin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbladminlogin`
--
ALTER TABLE `tbladminlogin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblstudenttakers`
--
ALTER TABLE `tblstudenttakers`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblviewclass`
--
ALTER TABLE `tblviewclass`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblviewedroom`
--
ALTER TABLE `tblviewedroom`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbstudentlist`
--
ALTER TABLE `tbstudentlist`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbstudentloggedin`
--
ALTER TABLE `tbstudentloggedin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbstudentlogin`
--
ALTER TABLE `tbstudentlogin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbteacherclassroom`
--
ALTER TABLE `tbteacherclassroom`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbteacherlistofexercises`
--
ALTER TABLE `tbteacherlistofexercises`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbteacherlistoflessons`
--
ALTER TABLE `tbteacherlistoflessons`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbteacherlogin`
--
ALTER TABLE `tbteacherlogin`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tbteachersloggedin`
--
ALTER TABLE `tbteachersloggedin`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbadminloggedin`
--
ALTER TABLE `tbadminloggedin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `tbladminlogin`
--
ALTER TABLE `tbladminlogin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tblstudenttakers`
--
ALTER TABLE `tblstudenttakers`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tblviewclass`
--
ALTER TABLE `tblviewclass`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tblviewedroom`
--
ALTER TABLE `tblviewedroom`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbstudentlist`
--
ALTER TABLE `tbstudentlist`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tbstudentloggedin`
--
ALTER TABLE `tbstudentloggedin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `tbstudentlogin`
--
ALTER TABLE `tbstudentlogin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbteacherclassroom`
--
ALTER TABLE `tbteacherclassroom`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbteacherlistofexercises`
--
ALTER TABLE `tbteacherlistofexercises`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `tbteacherlistoflessons`
--
ALTER TABLE `tbteacherlistoflessons`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbteacherlogin`
--
ALTER TABLE `tbteacherlogin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbteachersloggedin`
--
ALTER TABLE `tbteachersloggedin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
